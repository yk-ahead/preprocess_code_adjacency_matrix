eval(js `var foo`)
// <- function
//    ^ function
//        ^ keyword
//            ^ variable
