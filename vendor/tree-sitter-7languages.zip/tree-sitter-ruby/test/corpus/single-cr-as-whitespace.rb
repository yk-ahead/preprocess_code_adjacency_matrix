==================================
Single CR characters as whitespace
==================================

puts"hi"

---

(program (call (identifier) (argument_list (string (string_content)))))
