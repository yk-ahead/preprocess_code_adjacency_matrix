tree-sitter-ruby
================

[![build](https://github.com/tree-sitter/tree-sitter-ruby/actions/workflows/ci.yml/badge.svg)](https://github.com/tree-sitter/tree-sitter-ruby/actions/workflows/ci.yml)

Ruby grammar for [tree-sitter](https://github.com/tree-sitter/tree-sitter).

#### References

* [AST Format of the Whitequark parser](https://github.com/whitequark/parser/blob/master/doc/AST_FORMAT.md)
